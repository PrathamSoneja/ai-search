import os
import uuid
import pytesseract
import pdfplumber
from pdf2image import convert_from_path
from azure.core.credentials import AzureKeyCredential
from azure.search.documents import SearchClient
from azure.search.documents.indexes import SearchIndexClient
from azure.search.documents.indexes.models import (
    SearchIndex, SimpleField, SearchableField, SemanticSettings,
    SemanticConfiguration, PrioritizedFields
)
from langchain.text_splitter import CharacterTextSplitter

# === CONFIGURATION ===
PDF_FOLDER = "papers/"
SERVICE_ENDPOINT = "https://hduopenai.openai.azure.com/"
API_KEY = "8nclYiTbnRV7FEP5dkH27kBcLuI0d3LDhwC98gn49ptuiHt62B1CJQQJ99BBAC77bzfXJ3w3AAABACOGLwCL"
INDEX_NAME = "pdf-chunks-index"
CHUNK_SIZE = 1000
CHUNK_OVERLAP = 100
OCR_FALLBACK = True

# === Initialize text splitter ===
text_splitter = CharacterTextSplitter(
    separator="\n",
    chunk_size=CHUNK_SIZE,
    chunk_overlap=CHUNK_OVERLAP
)

# === Extract Text from PDF with OCR fallback ===
def extract_text_per_page(pdf_path):
    page_texts = []
    with pdfplumber.open(pdf_path) as pdf:
        for i, page in enumerate(pdf.pages):
            page_text = page.extract_text()
            if page_text and page_text.strip():
                page_texts.append((i + 1, page_text))
            elif OCR_FALLBACK:
                images = convert_from_path(pdf_path, first_page=i+1, last_page=i+1)
                ocr_text = pytesseract.image_to_string(images[0])
                page_texts.append((i + 1, ocr_text))
    return page_texts

# === Create or Update Azure AI Search Index ===
def create_index():
    credential = AzureKeyCredential(API_KEY)
    index_client = SearchIndexClient(endpoint=SERVICE_ENDPOINT, credential=credential)

    fields = [
        SimpleField(name="id", type="Edm.String", key=True),
        SearchableField(name="content", type="Edm.String", searchable=True),
        SimpleField(name="filename", type="Edm.String", filterable=True),
        SimpleField(name="page_number", type="Edm.Int32", filterable=True),
        SimpleField(name="chunk_id", type="Edm.Int32", filterable=True)
    ]

    semantic_config = SemanticConfiguration(
        name="default",
        prioritized_fields=PrioritizedFields(
            content_fields=["content"]
        )
    )

    index = SearchIndex(
        name=INDEX_NAME,
        fields=fields,
        semantic_settings=SemanticSettings(configurations=[semantic_config])
    )

    # Create or update index
    if INDEX_NAME in [idx.name for idx in index_client.list_indexes()]:
        index_client.delete_index(INDEX_NAME)
    index_client.create_index(index)
    print("✅ Azure AI Search index created.")

# === Upload documents to Azure AI Search ===
def upload_documents(docs):
    search_client = SearchClient(endpoint=SERVICE_ENDPOINT, index_name=INDEX_NAME, credential=AzureKeyCredential(API_KEY))
    result = search_client.upload_documents(documents=docs)
    print(f"📤 Uploaded {len(docs)} documents. Upload result: {result[0].status_code}")

# === Process PDFs and Upload to Azure Search ===
def process_and_upload():
    all_chunks = []
    for filename in os.listdir(PDF_FOLDER):
        if not filename.endswith(".pdf"):
            continue
        pdf_path = os.path.join(PDF_FOLDER, filename)
        print(f"📄 Processing {filename}...")

        page_texts = extract_text_per_page(pdf_path)
        for page_number, page_text in page_texts:
            chunks = text_splitter.split_text(page_text)
            for chunk_id, chunk in enumerate(chunks):
                all_chunks.append({
                    "id": str(uuid.uuid4()),
                    "content": chunk,
                    "filename": filename,
                    "page_number": page_number,
                    "chunk_id": chunk_id
                })

    upload_documents(all_chunks)
    print("✅ All PDF chunks uploaded to Azure AI Search.")

# === Perform Hybrid Search ===
def hybrid_search(query, top_k=5):
    search_client = SearchClient(endpoint=SERVICE_ENDPOINT, index_name=INDEX_NAME, credential=AzureKeyCredential(API_KEY))
    results = search_client.search(
        search_text=query,
        top=top_k,
        query_type="semantic",
        semantic_configuration_name="default",
        query_caption="extractive"
    )

    print(f"\n🔍 Top {top_k} Results for query: \"{query}\"\n")
    for result in results:
        print(f"📎 File: {result['filename']} | Page: {result['page_number']} | Chunk: {result['chunk_id']}")
        print(f"🔹 Content: {result['content'][:200]}...")
        if result.get("@search.captions"):
            print(f"💡 Caption: {result['@search.captions'][0]['text']}")
        print("---")

# === MAIN EXECUTION ===
if __name__ == "__main__":
    create_index()
    process_and_upload()
    hybrid_search("How does Azure AI Search work?")
