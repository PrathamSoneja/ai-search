import os
import json
import pytesseract
import pdfplumber
from pdf2image import convert_from_path
from fastapi import FastAPI, UploadFile, File, Query, Form
from fastapi.responses import JSONResponse
from typing import List
from langchain.text_splitter import CharacterTextSplitter
from langchain.embeddings import HuggingFaceEmbeddings
from langchain.vectorstores import FAISS
from fastapi.middleware.cors import CORSMiddleware
import uuid


# === CONFIGURATION ===
PDF_FOLDER = "papers/"
INDEX_FOLDER = "faiss_index"
HISTORY_FILE = "search_history.json"
EMBED_MODEL = "all-MiniLM-L6-v2"
CHUNK_SIZE = 1000
CHUNK_OVERLAP = 100
OCR_FALLBACK = True

# === Initialize app ===
app = FastAPI(title="Research Paper Search API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

text_splitter = CharacterTextSplitter(
    separator="\n",
    chunk_size=CHUNK_SIZE,
    chunk_overlap=CHUNK_OVERLAP
)

embedding_model = HuggingFaceEmbeddings(model_name=EMBED_MODEL)
vectorstore: FAISS = None  # Will be initialized at startup

# === Helpers ===
def extract_text_per_page(pdf_path):
    page_texts = []
    with pdfplumber.open(pdf_path) as pdf:
        for i, page in enumerate(pdf.pages):
            page_text = page.extract_text()
            if page_text and page_text.strip():
                page_texts.append((i + 1, page_text))
            elif OCR_FALLBACK:
                images = convert_from_path(pdf_path, first_page=i + 1, last_page=i + 1)
                ocr_text = pytesseract.image_to_string(images[0])
                page_texts.append((i + 1, ocr_text))
    return page_texts

def process_pdf(pdf_path, filename):
    documents, metadatas = [], []
    page_texts = extract_text_per_page(pdf_path)

    for page_number, page_text in page_texts:
        chunks = text_splitter.split_text(page_text)
        for chunk_id, chunk in enumerate(chunks):
            documents.append(chunk)
            metadatas.append({
                "filename": filename,
                "page_number": page_number,
                "chunk_id": chunk_id
            })

    return documents, metadatas

def initialize_faiss_from_folder():
    documents, metadatas = [], []
    for filename in os.listdir(PDF_FOLDER):
        if not filename.endswith(".pdf"):
            continue
        filepath = os.path.join(PDF_FOLDER, filename)
        print(f"Indexing: {filename}")
        doc_chunks, meta_chunks = process_pdf(filepath, filename)
        documents.extend(doc_chunks)
        metadatas.extend(meta_chunks)

    if documents:
        faiss_store = FAISS.from_texts(texts=documents, embedding=embedding_model, metadatas=metadatas)
        faiss_store.save_local(INDEX_FOLDER)
        return faiss_store
    return FAISS.from_texts([], embedding=embedding_model)

def hybrid_search(query: str, top_k: int = 5) -> List[dict]:
    global vectorstore
    vector_hits = vectorstore.similarity_search(query, k=top_k * 2)

    scored = []
    for doc in vector_hits:
        score = doc.page_content.lower().count(query.lower())
        scored.append((score, doc))

    scored = sorted(scored, key=lambda x: -x[0])
    results = []
    for score, doc in scored[:top_k]:
        filename = doc.metadata["filename"]
        results.append({
            "filename": filename,
            "page_number": doc.metadata["page_number"],
            "chunk_id": doc.metadata["chunk_id"],
            "content": doc.page_content[:500],
            "link": f"https://arxiv.org/abs/{filename}"  # Modify if serving actual URLs
        })
    return results

def save_search_history(query: str, results: List[dict]):
    history_entry = {
        "history_id": str(uuid.uuid4()),
        "query": query,
        "results": results
    }

    history = []
    if os.path.exists(HISTORY_FILE):
        with open(HISTORY_FILE, "r") as f:
            try:
                history = json.load(f)
            except json.JSONDecodeError:
                history = []

    history.insert(0, history_entry)
    history = history[:100]  # Limit size
    with open(HISTORY_FILE, "w") as f:
        json.dump(history, f, indent=2)


def load_search_history(limit: int = 10):
    if not os.path.exists(HISTORY_FILE):
        return []
    with open(HISTORY_FILE, "r") as f:
        try:
            history = json.load(f)
            return history[:limit]
        except json.JSONDecodeError:
            return []

# === API ENDPOINTS ===
@app.on_event("startup")
def on_startup():
    global vectorstore
    print("📥 Initializing FAISS from PDF folder...")
    os.makedirs(PDF_FOLDER, exist_ok=True)
    vectorstore = initialize_faiss_from_folder()
    if not vectorstore:
        print("⚠️ No documents found.")

@app.post("/search")
def search(query: str = Form(...), top_k: int = Form(5)):
    if not query:
        return JSONResponse({"error": "Query cannot be empty"}, status_code=400)

    results = hybrid_search(query, top_k=top_k)
    save_search_history(query, results)
    return {"results": results, "query": query, "top_k": top_k}

@app.post("/upload")
async def upload_file(file: UploadFile = File(...)):
    global vectorstore
    if not file.filename.endswith(".pdf"):
        return JSONResponse({"error": "Only PDF files are supported"}, status_code=400)

    filepath = os.path.join(PDF_FOLDER, file.filename)
    with open(filepath, "wb") as f:
        f.write(await file.read())

    documents, metadatas = process_pdf(filepath, file.filename)
    if not documents:
        return JSONResponse({"error": "No valid content found in PDF"}, status_code=400)

    vectorstore.add_texts(texts=documents, metadatas=metadatas)
    vectorstore.save_local(INDEX_FOLDER)

    return {"message": f"File '{file.filename}' uploaded and indexed.", "chunks_added": len(documents)}

@app.get("/history/top")
def get_top_history(limit: int = Query(10)):
    history = load_search_history(limit=limit)
    return {"top_history": history}

@app.delete("/history/clear")
def clear_search_history():
    if os.path.exists(HISTORY_FILE):
        with open(HISTORY_FILE, "w") as f:
            json.dump([], f, indent=2)
    return {"message": "Search history cleared."}

